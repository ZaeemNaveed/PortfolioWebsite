# AboutME - Free HTML Responsive Website Template for Online Portfolio/Resume/Profile
--------------------------------------------
<a href="https://designdrastic.com/template/aboutme-classic-portfolio-template"><strong>View Post</strong></a><br />
<a href="https://designdrastic.github.io/AboutME/"><strong>View Demo</strong></a><br />

![Demo](/1560151130-AboutME-tiny.png)

# Terms of Use

  - The offered resources can be used on any personal projects as-is format.
  - For commerical usages of the offered resources, you must link back our article and/or link as credit.
  - Free  resources can be used  in your personal or commercial projects with the exception of redistribution, republishing or sale of the item itself, portion of the item, or edited versions of same item (be it template, snippet or mockup).
  - Please visit [website](http://designdrastic.com) for updated Terms and Conditions, changed time by time.

### FAQs

Under which license you are providing these templates?
* They  under Creative Commons Attribution 3.0 unported

I want to remove designdrastic.com backlink from template. How can I?
* You can contact us for the same and we will guide you on how to pay for it.

Does these templates work on smarpthone based on iPhone, Android platforms and desktop browsers?
* Yes, all of templates work with all devices.

Does this template can be used to build WordPress themes?
* You can use the templates to build WordPress themes but must should credit us.

### Installation

- Clone or Download the ZIP. 
- Extract the zip file to the server root
- Visit your site by entering domain name or IP in browser URL


License
----

Creative Commons Attribution 3.0 unported (Link attribution is required)

